import { useState } from "react";

const createDeck = () => {
  const deck = [];
  for (let i = 0; i < 40; i++) {
    deck.push({
      id: i,
      type: i % 8 === 0 ? "Climax" : "Character",
      soul: 1,
      image:
        i % 8 === 0
          ? "https://en.ws-tcg.com/wordpress/wp-content/images/cardlist/s/smp_w82/smp_w82_100.png"
          : "https://en.ws-tcg.com/wordpress/wp-content/images/cardlist/s/smp_w60/smp_w60_079.png"
    });
  }
  return deck.sort(() => Math.random() - 0.5);
};

export default function App() {
  const [deck, setDeck] = useState(createDeck());
  const [hand, setHand] = useState([]);
  const [clock, setClock] = useState([]);
  const [level, setLevel] = useState([]);
  const [stage, setStage] = useState([null, null, null]);

  const draw = () => {
    if (deck.length === 0) return;
    const newDeck = [...deck];
    const card = newDeck.shift();
    setDeck(newDeck);
    setHand([...hand, card]);
  };

  const attack = (index) => {
    const attacker = stage[index];
    if (!attacker) return;

    let newDeck = [...deck];
    const card = newDeck.shift();

    if (card?.type === "Climax") {
      alert("CANCEL!");
      setDeck(newDeck);
      return;
    }

    setClock([...clock, card]);
    setDeck(newDeck);
  };

  return (
    <div className="playmat">
      <h2>Weiss Schwarz Ao</h2>

      <div>Deck: {deck.length} | Clock: {clock.length}</div>

      <div className="stage">
        {stage.map((card, i) => (
          <div key={i} className="slot" onClick={() => attack(i)}>
            {card && <img src={card.image} />}
          </div>
        ))}
      </div>

      <div className="hand">
        {hand.map((card) => (
          <img key={card.id} src={card.image} />
        ))}
      </div>

      <button onClick={draw}>Draw</button>
    </div>
  );
}
